---
name: Terran Craft
colors:
  surface: '#fefae0'
  surface-dim: '#dedbc2'
  surface-bright: '#fefae0'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f4db'
  surface-container: '#f2efd5'
  surface-container-high: '#ede9cf'
  surface-container-highest: '#e7e3ca'
  on-surface: '#1d1c0d'
  on-surface-variant: '#45483f'
  inverse-surface: '#323120'
  inverse-on-surface: '#f5f1d8'
  outline: '#75786e'
  outline-variant: '#c5c8bc'
  surface-tint: '#546341'
  primary: '#142005'
  on-primary: '#ffffff'
  primary-container: '#283618'
  on-primary-container: '#8fa078'
  inverse-primary: '#bbcda3'
  secondary: '#586330'
  on-secondary: '#ffffff'
  secondary-container: '#d8e6a6'
  on-secondary-container: '#5c6834'
  tertiary: '#311500'
  on-tertiary: '#ffffff'
  tertiary-container: '#502700'
  on-tertiary-container: '#db853c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d7e9bd'
  primary-fixed-dim: '#bbcda3'
  on-primary-fixed: '#121f05'
  on-primary-fixed-variant: '#3d4b2b'
  secondary-fixed: '#dbe9a9'
  secondary-fixed-dim: '#bfcd8f'
  on-secondary-fixed: '#171e00'
  on-secondary-fixed-variant: '#404b1b'
  tertiary-fixed: '#ffdcc4'
  tertiary-fixed-dim: '#ffb781'
  on-tertiary-fixed: '#2f1400'
  on-tertiary-fixed-variant: '#6f3800'
  background: '#fefae0'
  on-background: '#1d1c0d'
  surface-variant: '#e7e3ca'
  warm-ochre: '#dda15e'
  deep-forest: '#283618'
  moss-green: '#606c38'
  raw-amber: '#bc6c25'
  cornsilk-surface: '#fefae0'
typography:
  display-lg:
    fontFamily: Newsreader
    fontSize: 56px
    fontWeight: '500'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Newsreader
    fontSize: 38px
    fontWeight: '500'
    lineHeight: 46px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '500'
    lineHeight: 48px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '500'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: Newsreader
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies an earthy, rooted aesthetic balanced with refined modern typography and deliberate visual contrast. It is built for platforms celebrating sustainable commerce, outdoor exploration, artisan production, and botanical science. 

The aesthetic is Tactile Modernism: it combines organic warmth with precise architectural layout. It avoids sterile white-space minimalism in favor of rich, textured cream planes, deep botanical silhouettes, and resonant ochre accents. The emotional response is grounded, trustworthy, intentional, and intimately connected to natural raw materials.

## Colors

The palette draws directly from dense flora, fertile clay, and sunlit grain. 

- **Primary (`#283618`)**: Deep Earth Green. Anchor for high-priority interactive elements, primary headlines, and dominant navigation bars. Provides formidable contrast against light backgrounds.
- **Secondary (`#606C38`)**: Dark Moss Green. Applied to secondary controls, selected states, informative badges, and secondary structural containers.
- **Tertiary (`#BC6C25`)**: Tiger's Eye / Rich Earth Brown. A tactile accent used to signal active highlights, focal call-to-actions, and key interactive markers.
- **Neutral (`#FEFAE0`)**: Cornsilk / Warm Cream. The universal foundational surface. Replaces stark optical whites to eliminate clinical chill and establish ambient warmth.
- **Named Accent (`#DDA15E`)**: Warm Ochre. Used for subtle hover states, tertiary highlights, warning states, and decorative dividing accents.

Text contrast strictly enforces accessibility standards: Deep Earth Green (`#283618`) on Warm Cream (`#FEFAE0`) exceeds AAA standards for both large and normal text.

## Typography

The typographic hierarchy balances literary prestige with utilitarian clarity. 

- **Headlines (Newsreader)**: An editorial serif pairing that conveys heritage, craftsmanship, and grounded authority. Headings feature moderate tracking and robust weights to hold presence against dark natural tones.
- **Body & Labels (Inter)**: Delivers geometric neutrality, high legibility at micro-scales, and clean data density.

Desktop headlines scale down systematically on viewports under 768px (`display-lg-mobile` and `headline-lg-mobile`) to prevent awkward line breaks and overflow while maintaining visual punch.

## Layout & Spacing

This design system uses a flexible 12-column grid anchored by an 8pt spatial cadence. 

- **Desktop (1024px and above)**: 12 columns, 3rem margins, 1.5rem gutters. Content is contained within a max-width of 1280px to preserve comfortable scan-lines.
- **Tablet (768px – 1023px)**: 8 columns, 2rem margins, 1.25rem gutters.
- **Mobile (Below 768px)**: 4 columns, 1.25rem margins, 1rem gutters. Columns stretch fluidly.

Component padding relies strictly on the `space-*` scale:
- `space-xs` (4px): Dense chip spacing, icon-to-text offsets.
- `space-sm` (8px): Form input inner vertical padding, button inline gaps.
- `space-md` (16px): Standard card inner padding, stacked form field gaps.
- `space-lg` (24px): Complex card groupings, hero section element offsets.
- `space-xl` (40px): Section divisions, major module stacking.

## Elevation & Depth

To remain faithful to earthy textures, depth is primarily communicated via tonal layering and structural borders rather than diffuse digital drop-shadows.

- **Base Surface**: `#FEFAE0` serves as the canvas ground plane.
- **Elevated Surfaces**: Raised modules utilize subtle tint shifts (e.g., `#F4EFC7` or `#FFFFFF` overlay at 60% opacity) encased in low-contrast borders: `1px solid rgba(40, 54, 24, 0.12)`.
- **Tactile Ambient Shadow**: When physical floating elevation is mandatory (e.g., popovers, dropdowns, and flyout navigation), employ warm-tinted, muted shadows:
  `box-shadow: 0 8px 24px -4px rgba(40, 54, 24, 0.14), 0 2px 6px -1px rgba(40, 54, 24, 0.08)`.
- **Layered Stacking**: Dark Forest Green (`#283618`) surfaces should appear flush or sunken, using Ochre or Cream text to create strong optical cuts.

## Shapes

The shape profile is set to **Soft** (`roundedness: 1`). Architectural firmness is preserved through measured, subtle edge softenings that evoke cut stone, milled lumber, or book binding.

- **Inputs, Badges, and Small Buttons**: 0.25rem (`4px`) border radius.
- **Cards, Modals, and Flyouts**: 0.5rem (`8px`) border radius (`rounded-lg`).
- **Feature Banners & Overlays**: 0.75rem (`12px`) border radius (`rounded-xl`).

Pill-shapes and fully round radii are avoided except for circular avatar masks and unselected state radio toggles.

## Components

### Buttons
- **Primary**: Solid Deep Earth Green (`#283618`) fill, Warm Cream (`#FEFAE0`) text, 0.25rem border-radius. Active/Hover shifts to Dark Moss Green (`#606C38`).
- **Secondary**: Transparent background, 1.5px border in `#283618`, text in `#283618`. Hover fills with `rgba(96, 108, 56, 0.08)`.
- **Accent (Tertiary)**: Solid Tiger's Eye (`#BC6C25`) fill, Warm Cream (`#FEFAE0`) text. Reserved for high-value transactional conversions.

### Chips & Badges
- Compact 0.25rem radius containers.
- Neutral variant: `#DDA15E` at 20% opacity with `#283618` label text.
- Selected variant: Solid Dark Moss Green (`#606C38`) with `#FEFAE0` text.

### Inputs & Form Elements
- **Input Fields**: Crisp `#FEFAE0` base with a 1px border of `rgba(40, 54, 24, 0.25)`. Text set in `body-md` using `#283618`. Focus state introduces a 2px outline in `#606C38` with zero blur offset.
- **Checkboxes & Radios**: Custom square/round elements with `#283618` borders. Selected states fill with `#283618` accompanied by `#FEFAE0` check icons.

### Cards
- Surface tinted with Warm Cream (`#FEFAE0`) with a 1px border in `rgba(40, 54, 24, 0.1)`. Padding set to `space-md` or `space-lg`.
- Highlight cards use Dark Earth Green (`#283618`) backgrounds with inverted Warm Cream (`#FEFAE0`) typography and Ochre (`#DDA15E`) subtext.

### Lists & Dividers
- Item separations use hairline rules colored with `rgba(40, 54, 24, 0.12)`.
- Interactive list tiles exhibit a subtle background shift to `rgba(221, 161, 94, 0.12)` upon hover.