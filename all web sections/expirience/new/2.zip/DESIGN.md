---
name: Ignite Obsidian
colors:
  surface: '#0c1229'
  surface-dim: '#0c1229'
  surface-bright: '#333851'
  surface-container-lowest: '#070c24'
  surface-container-low: '#151a32'
  surface-container: '#191e36'
  surface-container-high: '#232941'
  surface-container-highest: '#2e334c'
  on-surface: '#dde1ff'
  on-surface-variant: '#e8bdb6'
  inverse-surface: '#dde1ff'
  inverse-on-surface: '#2a2f48'
  outline: '#ae8881'
  outline-variant: '#5e3f3a'
  surface-tint: '#ffb4a8'
  primary: '#ffb4a8'
  on-primary: '#690000'
  primary-container: '#d00000'
  on-primary-container: '#ffded9'
  inverse-primary: '#c00000'
  secondary: '#ffc070'
  on-secondary: '#462a00'
  secondary-container: '#f49e00'
  on-secondary-container: '#603c00'
  tertiary: '#ffb4a3'
  on-tertiary: '#630f00'
  tertiary-container: '#c52800'
  on-tertiary-container: '#ffded7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#930000'
  secondary-fixed: '#ffddb6'
  secondary-fixed-dim: '#ffb95b'
  on-secondary-fixed: '#2a1800'
  on-secondary-fixed-variant: '#643f00'
  tertiary-fixed: '#ffdad2'
  tertiary-fixed-dim: '#ffb4a3'
  on-tertiary-fixed: '#3d0600'
  on-tertiary-fixed-variant: '#8b1900'
  background: '#0c1229'
  on-background: '#dde1ff'
  surface-variant: '#2e334c'
  plum-obsidian: '#370617'
  deep-crimson: '#6A040F'
  rich-carmine: '#9D0208'
  blaze-orange: '#E85D04'
  radiant-tangerine: '#F48C06'
  amber-gold: '#FFBA08'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels an intense, luminous energy rooted in an obsidian-dark foundation illuminated by layered crimson, vermilion, and warm amber light. The brand personality is bold, cinematic, precise, and high-octane—engineered for high-impact platforms, media streaming hubs, performance-driven fintech, or creative software requiring visual momentum and immersive depth.

The design movement merges **High-Contrast Dark Surface Design** with **Volumetric Luminous Glassmorphism**. Dark plum and void-black foundations anchor the viewport, allowing chromatic embers to pierce through with dimensional glowing effects, elevated radial highlights, and crisp micro-details. Interface elements feel like glowing crystal lenses and polished obsidian slabs, delivering warmth and focused hierarchy without causing visual fatigue.

## Colors

The palette operates on a thermal spectrum moving from cold deep space into incandescent molten gold:

- **Primary (`#D00000`)**: The core kinetic accent used for vital calls-to-action, key state transitions, and primary interactive signals.
- **Secondary (`#FAA307`)**: High-luminance amber used for focus rings, contextual badges, active state indicators, and radiant focal points.
- **Tertiary (`#DC2F02`)**: Saturated vermilion acting as a bridge between crimson depth and amber luminosity; ideal for interactive hover states and gradient anchors.
- **Neutral (`#03071E`)**: The void background canvas. Tinted with blue-black undertones, it ensures reds and oranges appear luminous rather than harsh.
- **Named Spectrum**:
  - `plum-obsidian` (`#370617`) and `deep-crimson` (`#6A040F`) form elevated container backgrounds, surface cards, and tonal depth borders.
  - `rich-carmine` (`#9D0208`) provides active pressed states and subdued emphasis.
  - `blaze-orange` (`#E85D04`), `radiant-tangerine` (`#F48C06`), and `amber-gold` (`#FFBA08`) serve as thermal accents, metrics highlights, and elevated halo glow gradients.

Text on dark surfaces utilizes high-grade opacities of neutral off-white (`rgba(255, 255, 255, 0.95)` for titles, `rgba(255, 255, 255, 0.72)` for body copy, and `rgba(255, 255, 255, 0.44)` for disabled or placeholder content).

## Typography

The typographic hierarchy combines **Plus Jakarta Sans** for expressive, authoritative headlines with **Inter** for neutral, utilitarian legibility in dense data contexts.

- **Headlines & Display**: Plus Jakarta Sans brings geometric precision softened with modern curves. At large scales, tight negative letter spacing produces an impactful editorial posture that commands immediate attention against dark canvases.
- **Body & Data**: Inter handles long-form copy, descriptions, and functional elements. Its neutral proportions balance the intense chromatic energy of the fiery palette, preventing the interface from feeling visual or typographic noise.
- **Labels & Microcopy**: Formatted in Inter with increased tracking (+0.02em to +0.04em) and medium-to-bold weights to preserve contrast and readability on deep backgrounds.

## Layout & Spacing

The system is structured on a strict **8pt base grid** with a responsive fluid layout framework:

- **Desktop (1200px+)**: 12-column grid, 24px (`1.5rem`) gutters, dynamic section margin expanding up to a maximum container width of 1440px with `2rem` outer padding.
- **Tablet (768px - 1199px)**: 8-column grid, 20px gutters, and 24px outer margins.
- **Mobile (< 768px)**: 4-column grid, 16px gutters, and 16px (`1rem`) outer canvas margins.

Components enforce internal density via the spacing scale:
- `space-xs` (4px) and `space-sm` (8px) govern tight inline groups (icon-to-text gaps, segmented control chips).
- `space-md` (16px) sets standard card padding, stacked form rows, and list separation.
- `space-lg` (24px) and `space-xl` (40px) orchestrate section blocks, modal shells, and distinct dashboard modular clusters.

## Elevation & Depth

Visual hierarchy is communicated through **ambient chromatic illumination** and **nested translucent surfaces** rather than traditional neutral drop shadows:

1. **Surface 0 (Base Canvas)**: Pure `#03071E`.
2. **Surface 1 (Card & Module Shells)**: Translucent Obsidian (`rgba(55, 6, 23, 0.35)`) backed with a `16px` backdrop blur and a crisp `1px` inner rim light (`rgba(255, 186, 8, 0.12)`).
3. **Surface 2 (Floating Modals & Flyouts)**: Deep Crimson (`rgba(106, 4, 15, 0.65)`) layered over a `24px` backdrop blur, edged with a 1px border (`rgba(220, 47, 2, 0.3)`), cast with a soft ambient blur: `0 16px 40px -8px rgba(0, 0, 0, 0.7)`.
4. **Vibrant Pop-Out Circles (Luminous Highlights)**: Floating circular avatars, stats orbs, and focal badges feature radial lighting. They emit a multi-stage thermal halo:
   - Primary glow: `0 0 24px 0 rgba(208, 0, 0, 0.45)`.
   - Secondary ring highlight: A 2px gradient stroke transitioning from `#FFBA08` at the top-left light source to `#9D0208` at the bottom-right.
   - Core fill: Radial gradient from `#F48C06` into `#D00000`.

## Shapes

The design system adopts a roundedness factor of `2` (`rounded`: 8px / 0.5rem; `rounded-lg`: 16px / 1rem; `rounded-xl`: 24px / 1.5rem).

- **Standard Containers**: Input fields, buttons, and alert strips utilize the base 8px radius to keep interaction zones disciplined and structured.
- **Surface Cards & Modals**: Large content panes, preview panels, and cards employ `rounded-lg` (16px) or `rounded-xl` (24px) to soften larger silhouettes.
- **The Signature Circle**: To fulfill the pop-out visual motif, circular UI elements (icon anchors, status pills, floating badges, metric gauges) employ pure `rounded-full` (50%) geometry with internal specular edge lighting.

## Components

### Buttons
- **Primary**: Solid gradient fill from `#DC2F02` to `#D00000`. Text in white (`#FFFFFF`) with `label-md` styling. On hover, background shifts towards `#E85D04` with an ambient glow of `0 0 20px rgba(220, 47, 2, 0.5)`. Active states compress slightly (scale: 0.98).
- **Secondary**: Translucent background (`rgba(55, 6, 23, 0.6)`) with a 1px border in `#DC2F02`. Text in `#FFBA08`. Hover transitions border to `#F48C06` and illuminates background fill.
- **Ghost / Tertiary**: No background fill, 1px transparent border, text in `rgba(255, 255, 255, 0.8)`. Hover introduces a soft crimson wash (`rgba(106, 4, 15, 0.25)`).

### Vibrant Pop-Out Circles & Badges
- Floating stat circles and avatar wrappers are bounded by a dual-layer treatment: a solid outer circle border accented by a multi-stop gradient (`#FFBA08` through `#D00000`), an inner inset shadow giving a beveled convex lens feel, and a projected drop shadow casting colored light into the dark base canvas.

### Chips & Filters
- Compact height (32px), `rounded-full` contour.
- Unselected: Dark plum background (`#370617`), subtle border (`rgba(255, 255, 255, 0.08)`), text in `rgba(255, 255, 255, 0.64)`.
- Selected: Crimson-orange base (`#9D0208` to `#DC2F02`) with `#FFBA08` text, accompanied by an intense 6px luminous dot.

### Input Fields
- Structured at 44px height, `rounded` (8px), background of `#03071E` with a 1px boundary of `rgba(106, 4, 15, 0.5)`.
- Focus state: Border brightens to `#FAA307` accompanied by a continuous non-intrusive 3px outer halo in `rgba(250, 163, 7, 0.25)`. Text inputs feature high-contrast pure white text.

### Cards
- Obsidian glass container with a subtle vertical gradient: top starts at `rgba(55, 6, 23, 0.5)` tapering into `rgba(3, 7, 30, 0.8)`.
- Borders use a micro-fine 1px edge lit by a linear gradient flowing from top-left (`rgba(255, 186, 8, 0.25)`) to bottom-right (`rgba(106, 4, 15, 0.05)`).

### Checkboxes & Radio Buttons
- 20px geometric anchors with an 8px border-radius on checkboxes and 50% circular silhouette on radios.
- Unchecked: Inset dark surface with a 1.5px plum border (`#6A040F`).
- Checked: Radiant vermilion fill (`#D00000`) with a crisp amber-gold checkmark or inner core (`#FFBA08`), projecting an ambient 8px bloom.