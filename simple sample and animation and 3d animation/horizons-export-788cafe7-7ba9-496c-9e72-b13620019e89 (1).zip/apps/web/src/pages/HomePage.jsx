/* eslint-disable react/prop-types */
import React, { useEffect, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence, useScroll, useTransform } from 'framer-motion';
import { ArrowUpRight, ArrowDown, Menu, X } from 'lucide-react';
import Reveal from '@/components/Reveal';
import CountUp from '@/components/CountUp';

const IMG = {
	hero: 'https://images.hostinger.com/6c5fdde3-9802-401e-9247-9b8b1e6569d5.png',
	craft: 'https://images.hostinger.com/bd4032c3-2a53-4dfb-b13d-52c047ad9d5a.png',
	architecture: 'https://images.hostinger.com/e0d1079b-012a-4a8b-a90d-35f3f4336cc7.png',
	styling: 'https://images.hostinger.com/79c8f0ab-c4d1-4fab-9239-096a7a9419a0.png',
	kitchen: 'https://images.hostinger.com/ef925437-b7b2-4683-b46a-dc657bf30f3d.png',
	bedroom: 'https://images.hostinger.com/2d209d9c-2d55-4adb-9a3a-8c57fa2d22e9.png',
	lounge: 'https://images.hostinger.com/c2d67b46-28b2-42d8-a772-4897074ab7a0.png',
	dining: 'https://images.hostinger.com/fafe5d12-db30-40d3-b98d-3055c100e6a7.png',
	study: 'https://images.hostinger.com/f2f37bfa-2e09-4ad6-b4ad-07cf93e297ba.png',
	villa: 'https://images.hostinger.com/78caf28c-be7c-4e05-866a-bf3b0fdf26b7.png',
	// Materials & decor library
	matTeak: 'https://images.hostinger.com/c0807a00-69ff-4075-9f1a-9ea36b87688b.png',
	matBrass: 'https://images.hostinger.com/ef0b6e8b-efc5-4f7a-b8ff-adce17f22721.png',
	matMarble: 'https://images.hostinger.com/515d7077-0c81-4a78-bfcd-495caae24112.png',
	matLinen: 'https://images.hostinger.com/38165ce7-2a07-4630-8fca-5aadcf767b22.png',
	matLight: 'https://images.hostinger.com/1e189099-69c4-42d8-b489-3230d1cd4742.png',
	matCeramic: 'https://images.hostinger.com/1abee0e9-4bff-42ea-8b3d-c12fc3ff8cc0.png',
	// Completed works archive
	arcBath: 'https://images.hostinger.com/be07f3ae-081d-43d6-8cf4-e7689352676a.png',
	arcStair: 'https://images.hostinger.com/b5e99014-f8d2-44f5-b6ed-f3726e5e890c.png',
	arcPooja: 'https://images.hostinger.com/380eb636-3e01-495f-8a5c-4af2c32a5e14.png',
	arcTerrace: 'https://images.hostinger.com/74e302a5-69b2-497c-9284-9c9c9aa8bb0d.png',
};

const NAV = [
	{ label: 'Philosophy', href: '#philosophy' },
	{ label: 'Expertise', href: '#expertise' },
	{ label: 'Materials', href: '#materials' },
	{ label: 'Works', href: '#works' },
	{ label: 'Process', href: '#process' },
	{ label: 'Contact', href: '#contact' },
];

const SERVICES = [
	{
		n: '01',
		title: 'Interior Architecture',
		desc: 'Complete spatial planning for residences — light, proportion and movement resolved before a single finish is chosen.',
		img: IMG.architecture,
	},
	{
		n: '02',
		title: 'Bespoke Furniture',
		desc: 'Made-to-measure pieces from our own workshop — solid teak, brass joinery and stone, built to outlive trends.',
		img: IMG.craft,
	},
	{
		n: '03',
		title: 'Decoration & Styling',
		desc: 'The final layer: art, textiles, objects and greenery curated room by room until the house feels inhabited.',
		img: IMG.styling,
	},
	{
		n: '04',
		title: 'Turnkey Execution',
		desc: 'One atelier, one contract, one handover date. We manage civil work, vendors and site craft end to end.',
		img: IMG.kitchen,
	},
];

const WORKS_GRID = [
	{
		src: IMG.bedroom,
		aspect: 'aspect-[3/4]',
		fig: 'Fig. 03',
		title: 'Malabar Hill Residence',
		meta: 'Mumbai — 2024',
		cls: 'md:col-span-5',
	},
	{
		src: IMG.lounge,
		aspect: 'aspect-[3/2]',
		fig: 'Fig. 04',
		title: 'The Reading Lounge',
		meta: 'New Delhi — 2023',
		cls: 'md:col-span-6 md:col-start-7 md:mt-24',
	},
	{
		src: IMG.study,
		aspect: 'aspect-[3/4]',
		fig: 'Fig. 05',
		title: 'The Study, Worli',
		meta: 'Mumbai — 2023',
		cls: 'md:col-span-5 md:col-start-2 md:mt-16',
	},
	{
		src: IMG.kitchen,
		aspect: 'aspect-[4/3]',
		fig: 'Fig. 06',
		title: 'The Island Kitchen',
		meta: 'Gurugram — 2022',
		cls: 'md:col-span-7 md:col-start-6 md:-mt-8',
	},
];

const STEPS = [
	{
		n: '01',
		title: 'Listen',
		desc: 'We begin with how you live — mornings, rituals, the way light enters your rooms. The brief is a conversation, not a form.',
	},
	{
		n: '02',
		title: 'Design',
		desc: 'Plans, material palettes and 3D views, refined with you in weekly sittings until every corner earns its place.',
	},
	{
		n: '03',
		title: 'Craft',
		desc: 'Our workshop builds the furniture while site teams execute civil work — one calendar, one standard of finish.',
	},
	{
		n: '04',
		title: 'Deliver',
		desc: 'A styled handover, down to the last cushion and the first cup of tea. We return after a season to fine-tune.',
	},
];

const STATS = [
	{ value: 240, suffix: '+', label: 'Projects delivered' },
	{ value: 12, suffix: '', label: 'Years of practice' },
	{ value: 9, suffix: '', label: 'Cities across India' },
	{ value: 40, suffix: '+', label: 'Master artisans' },
];

const MATERIALS = [
	'Solid Teak',
	'Antique Brass',
	'Travertine Stone',
	'Hand-Loomed Linen',
	'Italian Marble',
	'Burnished Oak',
	'Limewash Plaster',
	'Cast Bronze',
];

const MATERIAL_LIBRARY = [
	{
		n: '01',
		title: 'Solid Teak',
		origin: 'Burma · aged 12 yrs',
		desc: 'Kiln-dried, hand-graded teak for joinery, doors and built-in furniture — chosen for grain and stability.',
		img: IMG.matTeak,
	},
	{
		n: '02',
		title: 'Antique Brass',
		origin: 'Moradabad · sand-cast',
		desc: 'Door handles, inlays and trims cast in small batches, then hand-patinated to a soft, living finish.',
		img: IMG.matBrass,
	},
	{
		n: '03',
		title: 'Italian Marble',
		origin: 'Carrara · book-matched',
		desc: 'Calacatta and Statuario slabs for floors, vanities and statement walls — selected at the quarry.',
		img: IMG.matMarble,
	},
	{
		n: '04',
		title: 'Hand-Loomed Linen',
		origin: 'Panipat · natural dye',
		desc: 'Upholstery, drapery and cushions woven from long-staple linen in warm, mineral-toned naturals.',
		img: IMG.matLinen,
	},
	{
		n: '05',
		title: 'Brass Lighting',
		origin: 'In-house · made to order',
		desc: 'Pendants, sconces and chandeliers designed in-studio and assembled with hand-blown glass shades.',
		img: IMG.matLight,
	},
	{
		n: '06',
		title: 'Stoneware & Ceramics',
		origin: 'Jaipur · hand-thrown',
		desc: 'Vases, vessels and objects turned on the wheel and glazed in earthy, one-of-a-kind tones.',
		img: IMG.matCeramic,
	},
];

const ARCHIVE = [
	{
		src: IMG.arcBath,
		fig: 'A.01',
		title: 'The Stone Bath',
		meta: 'Penthouse · Mumbai · 2024',
		type: 'Bathroom',
	},
	{
		src: IMG.arcStair,
		fig: 'A.02',
		title: 'Floating Stair, Foyer',
		meta: 'Villa · Pune · 2023',
		type: 'Architecture',
	},
	{
		src: IMG.arcPooja,
		fig: 'A.03',
		title: 'The Pooja Room',
		meta: 'Residence · Jaipur · 2023',
		type: 'Sacred Space',
	},
	{
		src: IMG.arcTerrace,
		fig: 'A.04',
		title: 'Dusk Terrace',
		meta: 'Penthouse · Mumbai · 2022',
		type: 'Outdoor',
	},
];

const AWARDS = [
	{ year: '2024', title: 'AD100 India', pub: 'Architectural Digest', note: 'Listed among the country’s most influential design practices.' },
	{ year: '2023', title: 'Residential Project of the Year', pub: 'IIID Awards', note: 'For the Malabar Hill Residence, Mumbai.' },
	{ year: '2023', title: 'Editorial Feature', pub: 'Elle Decor India', note: '“The Quiet Atelier” — a six-page studio profile.' },
	{ year: '2022', title: 'Best Besoke Interior', pub: 'India Design Awards', note: 'Recognising the Whitefield Villa, Bengaluru.' },
];

const lineReveal = {
	hidden: { y: '112%' },
	show: (i) => ({
		y: '0%',
		transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1], delay: 0.2 + i * 0.14 },
	}),
};

const fadeUp = {
	hidden: { opacity: 0, y: 24 },
	show: (i) => ({
		opacity: 1,
		y: 0,
		transition: { duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.5 + i * 0.12 },
	}),
};

function VerticalLabel({ children, className = '' }) {
	return (
		<span
			className={`pointer-events-none absolute top-1/2 hidden -translate-y-1/2 select-none text-[10px] font-medium uppercase tracking-[0.4em] [writing-mode:vertical-rl] rotate-180 xl:block ${className}`}
		>
			{children}
		</span>
	);
}

function SectionTag({ index, label, dark = false }) {
	return (
		<div
			className={`flex items-center gap-4 text-[10px] font-medium uppercase tracking-[0.35em] ${
				dark ? 'text-cream/50' : 'text-foreground/50'
			}`}
		>
			<span className="h-px w-10 bg-brass" />
			{index} — {label}
		</div>
	);
}

function Caption({ fig, title, meta, dark = false }) {
	return (
		<figcaption
			className={`mt-0 flex items-baseline justify-between gap-4 border-t py-3 text-[10px] uppercase tracking-[0.25em] ${
				dark ? 'border-cream/20 text-cream/50' : 'border-foreground/20 text-foreground/50'
			}`}
		>
			<span>
				{fig} — {title}
			</span>
			<span className="shrink-0">{meta}</span>
		</figcaption>
	);
}

function ScrollProgress() {
	const { scrollYProgress } = useScroll();
	const scaleX = useTransform(scrollYProgress, [0, 1], [0, 1]);
	return (
		<motion.div
			style={{ scaleX }}
			className="fixed inset-x-0 top-0 z-[70] h-[2px] origin-left bg-brass"
		/>
	);
}

function Header() {
	const [scrolled, setScrolled] = useState(false);
	const [open, setOpen] = useState(false);

	useEffect(() => {
		const onScroll = () => setScrolled(window.scrollY > 48);
		onScroll();
		window.addEventListener('scroll', onScroll, { passive: true });
		return () => window.removeEventListener('scroll', onScroll);
	}, []);

	const solid = scrolled && !open;

	return (
		<>
			<header
				className={`fixed inset-x-0 top-0 z-50 transition-colors duration-500 ${
					solid
						? 'border-b border-espresso/10 bg-cream/90 text-espresso backdrop-blur-md'
						: 'border-b border-transparent text-cream'
				}`}
			>
				<div className="mx-auto flex h-16 w-full max-w-[92rem] items-center justify-between px-6 md:h-20 md:px-12">
					<a href="#top" className="font-display text-lg font-medium tracking-[0.2em]">
						Aranya
					</a>
					<nav className="hidden items-center gap-10 lg:flex">
						{NAV.map((item) => (
							<a
								key={item.href}
								href={item.href}
								className="group relative text-[11px] font-medium uppercase tracking-[0.25em] opacity-80 transition-opacity duration-300 hover:opacity-100"
							>
								{item.label}
								<span className="absolute -bottom-1 left-0 h-px w-0 bg-brass transition-all duration-300 group-hover:w-full" />
							</a>
						))}
					</nav>
					<div className="flex items-center gap-4">
						<a
							href="#contact"
							className={`hidden items-center gap-2 border px-5 py-2.5 text-[10px] font-medium uppercase tracking-[0.25em] transition-colors duration-300 md:inline-flex ${
								solid
									? 'border-espresso/30 hover:bg-espresso hover:text-cream'
									: 'border-cream/40 hover:bg-cream hover:text-espresso'
							}`}
						>
							Book a consultation
							<ArrowUpRight className="h-3.5 w-3.5" />
						</a>
						<button
							type="button"
							aria-label="Open menu"
							onClick={() => setOpen(true)}
							className="inline-flex h-11 w-11 items-center justify-center lg:hidden"
						>
							<Menu className="h-5 w-5" />
						</button>
					</div>
				</div>
			</header>

			{open && (
				<div className="fixed inset-0 z-[60] flex flex-col bg-espresso text-cream">
					<div className="flex h-16 items-center justify-between px-6 md:h-20 md:px-12">
						<span className="font-display text-lg font-medium tracking-[0.2em]">Aranya</span>
						<button
							type="button"
							aria-label="Close menu"
							onClick={() => setOpen(false)}
							className="inline-flex h-11 w-11 items-center justify-center"
						>
							<X className="h-6 w-6" />
						</button>
					</div>
					<nav className="flex flex-1 flex-col justify-center gap-2 px-6 md:px-12">
						{NAV.map((item, i) => (
							<a
								key={item.href}
								href={item.href}
								onClick={() => setOpen(false)}
								className="group flex items-baseline gap-6 border-t border-cream/15 py-5"
							>
								<span className="text-[10px] tracking-[0.3em] text-cream/40">0{i + 1}</span>
								<span className="font-display text-4xl font-light transition-all duration-300 group-hover:translate-x-3 group-hover:text-brass">
									{item.label}
								</span>
							</a>
						))}
					</nav>
					<p className="px-6 pb-10 text-[10px] uppercase tracking-[0.3em] text-cream/40 md:px-12">
						Mumbai — New Delhi — Bengaluru
					</p>
				</div>
			)}
		</>
	);
}

function Hero() {
	const ref = useRef(null);
	const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
	const scale = useTransform(scrollYProgress, [0, 1], [1, 1.15]);
	const imgY = useTransform(scrollYProgress, [0, 1], [0, -60]);
	const contentY = useTransform(scrollYProgress, [0, 1], [0, 90]);
	const contentOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);

	return (
		<section
			id="top"
			ref={ref}
			className="relative h-[100dvh] min-h-[640px] w-full overflow-hidden bg-espresso"
		>
			<motion.div style={{ y: imgY, scale }} className="absolute inset-0 will-change-transform">
				<img
					src={IMG.hero}
					alt="Sunlit luxury living room with warm stone walls, oak furniture and a linen sofa in a Mumbai penthouse"
					className="h-full w-full object-cover"
				/>
			</motion.div>
			<div className="absolute inset-0 bg-gradient-to-t from-espresso-deep via-espresso/55 to-espresso/25" />
			<div className="absolute inset-0 bg-gradient-to-r from-espresso-deep/70 via-transparent to-transparent" />

			<motion.div
				style={{ y: contentY, opacity: contentOpacity }}
				className="relative z-10 mx-auto flex h-full w-full max-w-[92rem] flex-col justify-end px-6 pb-16 md:px-12 md:pb-24"
			>
				<motion.p
					variants={fadeUp}
					initial="hidden"
					animate="show"
					custom={0}
					className="mb-8 flex items-center gap-4 text-[10px] font-medium uppercase tracking-[0.35em] text-cream/70"
				>
					<span className="h-px w-10 bg-brass" />
					Interior Architecture — Furniture — Decoration
				</motion.p>

				<h1 className="font-display text-[clamp(2.75rem,8vw,7.5rem)] font-light leading-[0.95] tracking-[-0.03em] text-cream">
					<span className="block overflow-hidden pb-1">
						<motion.span variants={lineReveal} initial="hidden" animate="show" custom={0} className="block">
							Spaces that
						</motion.span>
					</span>
					<span className="block overflow-hidden pb-2 md:pl-[8vw]">
						<motion.span variants={lineReveal} initial="hidden" animate="show" custom={1} className="block">
							stay <span className="font-normal italic text-brass">with you.</span>
						</motion.span>
					</span>
				</h1>

				<div className="mt-10 grid grid-cols-12 items-end gap-8">
					<motion.p
						variants={fadeUp}
						initial="hidden"
						animate="show"
						custom={2}
						className="col-span-12 max-w-sm text-sm leading-relaxed text-cream/75 md:col-span-5"
					>
						Aranya is an interior atelier composing bespoke homes across India — from the first
						sketch to the final cushion, every detail resolved by one hand.
					</motion.p>
					<motion.div
						variants={fadeUp}
						initial="hidden"
						animate="show"
						custom={3}
						className="col-span-12 flex flex-wrap items-center gap-4 md:col-span-7 md:justify-end"
					>
						<a
							href="#contact"
							className="group inline-flex items-center gap-3 bg-brass px-8 py-4 text-[11px] font-medium uppercase tracking-[0.3em] text-espresso transition-colors duration-300 hover:bg-cream"
						>
							Book a consultation
							<ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
						</a>
						<a
							href="#works"
							className="group inline-flex items-center gap-3 border border-cream/40 px-8 py-4 text-[11px] font-medium uppercase tracking-[0.3em] text-cream transition-colors duration-300 hover:bg-cream hover:text-espresso"
						>
							View selected works
							<ArrowDown className="h-4 w-4" />
						</a>
					</motion.div>
				</div>
			</motion.div>

			<div className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-2 text-cream/60 md:flex">
				<span className="text-[10px] uppercase tracking-[0.3em]">Scroll</span>
				<motion.span
					animate={{ y: [0, 8, 0] }}
					transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
					className="block h-8 w-px bg-cream/40"
				/>
			</div>
		</section>
	);
}

function Marquee() {
	const row = [...MATERIALS, ...MATERIALS];
	return (
		<div className="relative overflow-hidden border-y border-cream/10 bg-espresso py-5 text-cream">
			<div className="flex w-max animate-marquee items-center gap-10 whitespace-nowrap">
				{row.map((it, i) => (
					<span
						key={i}
						className="flex items-center gap-10 text-[11px] font-medium uppercase tracking-[0.3em] text-cream/70"
					>
						{it}
						<span className="h-1.5 w-1.5 rotate-45 bg-brass" />
					</span>
				))}
			</div>
		</div>
	);
}

function Philosophy() {
	return (
		<section id="philosophy" className="relative bg-cream py-28 md:py-40">
			<VerticalLabel className="left-6 text-foreground/35">01 — Philosophy</VerticalLabel>
			<div className="mx-auto w-full max-w-[92rem] px-6 md:px-12">
				<Reveal>
					<SectionTag index="01" label="Philosophy" />
				</Reveal>
				<Reveal delay={0.1}>
					<h2 className="mt-10 max-w-5xl font-display text-4xl font-light leading-[1.05] tracking-[-0.02em] md:text-6xl">
						A home is not decorated — it is{' '}
						<span className="font-normal italic text-brass">composed</span>, room by room, around
						the people who live in it.
					</h2>
				</Reveal>

				<div className="mt-20 grid grid-cols-12 gap-8 md:mt-28">
					<div className="col-span-12 md:col-span-5">
						<Reveal delay={0.15}>
							<p className="max-w-md text-sm leading-relaxed text-foreground/70">
								We work slowly and deliberately. Every project begins with listening — to the
								family, the light, the building itself — before a single line is drawn. The
								result is not a style, but a temperament: rooms that feel inevitable, as if
								they could never have been otherwise.
							</p>
							<p className="mt-6 max-w-md text-sm leading-relaxed text-foreground/70">
								Furniture is built in our own workshop, finishes are sampled in daylight, and
								nothing is ordered until it has been touched. This is interior design as a
								craft, not a catalogue.
							</p>
							<div className="mt-10 flex items-center gap-6">
								<span className="font-display text-5xl font-light text-brass md:text-6xl">
									12
								</span>
								<span className="max-w-[12rem] text-[10px] uppercase tracking-[0.3em] text-foreground/50">
									Years composing homes across India
								</span>
							</div>
						</Reveal>
					</div>
					<figure className="col-span-12 md:col-span-5 md:col-start-8 md:mt-16">
						<Reveal delay={0.2}>
							<div className="overflow-hidden">
								<img
									src={IMG.craft}
									alt="Craftsman hand-finishing a carved teak chair with brass joinery in the Aranya workshop"
									className="aspect-[3/4] w-full object-cover transition-transform duration-700 ease-out hover:scale-[1.04]"
								/>
							</div>
							<Caption fig="Fig. 01" title="The workshop" meta="Jaipur" />
						</Reveal>
					</figure>
				</div>
			</div>
		</section>
	);
}

function Expertise() {
	const [active, setActive] = useState(0);

	return (
		<section id="expertise" className="relative bg-cream py-28 md:py-40">
			<VerticalLabel className="left-6 text-foreground/35">02 — Expertise</VerticalLabel>
			<div className="mx-auto w-full max-w-[92rem] px-6 md:px-12">
				<div className="flex flex-wrap items-end justify-between gap-6">
					<div>
						<Reveal>
							<SectionTag index="02" label="Expertise" />
						</Reveal>
						<Reveal delay={0.1}>
							<h2 className="mt-10 font-display text-4xl font-light leading-[1.05] tracking-[-0.02em] md:text-6xl">
								Everything a home needs,
								<br />
								under one roof.
							</h2>
						</Reveal>
					</div>
					<Reveal delay={0.15}>
						<p className="max-w-xs text-sm leading-relaxed text-foreground/60">
							Four disciplines, one team — so the architecture, the furniture and the styling
							never argue with each other. Hover to explore each.
						</p>
					</Reveal>
				</div>

				<div className="mt-16 grid grid-cols-1 gap-12 md:mt-24 lg:grid-cols-2 lg:gap-20">
					<div className="border-b border-foreground/15">
						{SERVICES.map((s, i) => (
							<Reveal key={s.n} delay={i * 0.06}>
								<button
									type="button"
									onMouseEnter={() => setActive(i)}
									onFocus={() => setActive(i)}
									onClick={() => setActive(i)}
									className="group grid w-full grid-cols-12 items-baseline gap-4 border-t border-foreground/15 py-8 text-left transition-colors duration-300 md:py-10"
								>
									<span
										className={`col-span-2 font-display text-xs tracking-[0.3em] transition-colors duration-300 md:col-span-1 ${
											active === i ? 'text-brass' : 'text-foreground/40'
										}`}
									>
										{s.n}
									</span>
									<h3
										className={`col-span-10 font-display text-2xl font-light tracking-[-0.01em] transition-all duration-300 md:col-span-11 md:text-4xl ${
											active === i ? 'translate-x-2 text-foreground' : 'text-foreground/55'
										}`}
									>
										{s.title}
									</h3>
									<p
										className={`col-span-10 col-start-3 mt-2 max-w-md text-sm leading-relaxed transition-opacity duration-300 md:col-span-10 md:col-start-2 ${
											active === i ? 'text-foreground/70 opacity-100' : 'text-foreground/45 opacity-80'
										}`}
									>
										{s.desc}
									</p>
								</button>
							</Reveal>
						))}
					</div>

					<div className="lg:sticky lg:top-32 lg:self-start">
						<div className="relative aspect-[4/5] overflow-hidden">
							<AnimatePresence mode="wait">
								<motion.img
									key={active}
									src={SERVICES[active].img}
									alt={`${SERVICES[active].title} — Aranya Interiors`}
									initial={{ opacity: 0, scale: 1.05 }}
									animate={{ opacity: 1, scale: 1 }}
									exit={{ opacity: 0 }}
									transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
									className="absolute inset-0 h-full w-full object-cover"
								/>
							</AnimatePresence>
							<div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-espresso-deep/70 via-transparent to-transparent" />
							<div className="absolute bottom-0 left-0 right-0 flex items-center justify-between p-6 text-cream md:p-8">
								<span className="font-display text-lg font-light md:text-2xl">
									{SERVICES[active].title}
								</span>
								<span className="text-[10px] uppercase tracking-[0.3em] text-brass">
									{SERVICES[active].n}
								</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
	);
}

function Works() {
	return (
		<section id="works" className="relative bg-sand py-28 md:py-40">
			<VerticalLabel className="left-6 text-foreground/35">04 — Selected Works</VerticalLabel>
			<div className="mx-auto w-full max-w-[92rem] px-6 md:px-12">
				<div className="flex flex-wrap items-end justify-between gap-6">
					<div>
						<Reveal>
							<SectionTag index="04" label="Selected Works" />
						</Reveal>
						<Reveal delay={0.1}>
							<h2 className="mt-10 font-display text-4xl font-light leading-[1.05] tracking-[-0.02em] md:text-6xl">
								Recent rooms,
								<br />
								quietly documented.
							</h2>
						</Reveal>
					</div>
					<Reveal delay={0.15}>
						<a
							href="#contact"
							className="group inline-flex items-center gap-3 border border-foreground/30 px-7 py-4 text-[11px] font-medium uppercase tracking-[0.3em] transition-colors duration-300 hover:bg-foreground hover:text-cream"
						>
							Request full portfolio
							<ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
						</a>
					</Reveal>
				</div>

				<Reveal delay={0.1}>
					<figure className="group relative mt-16 overflow-hidden md:mt-24">
						<div className="overflow-hidden">
							<img
								src={IMG.dining}
								alt="The dining hall of Whitefield Villa with a long oak table and brass pendant lights, designed by Aranya Interiors"
								className="aspect-[16/9] w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-[1.05]"
							/>
						</div>
						<figcaption className="absolute inset-0 flex flex-col justify-end bg-gradient-to-t from-espresso-deep/85 via-espresso/10 to-transparent p-8 text-cream md:p-12">
							<span className="text-[10px] uppercase tracking-[0.3em] text-brass">
								Featured — Fig. 02
							</span>
							<h3 className="mt-3 font-display text-3xl font-light leading-tight md:text-5xl">
								The Dining Hall, Whitefield Villa
							</h3>
							<p className="mt-2 text-[11px] uppercase tracking-[0.3em] text-cream/70">
								Bengaluru — 2024
							</p>
						</figcaption>
					</figure>
				</Reveal>

				<div className="mt-16 grid grid-cols-12 gap-x-8 gap-y-12 md:mt-24">
					{WORKS_GRID.map((w, i) => (
						<figure key={w.fig} className={`col-span-12 ${w.cls}`}>
							<Reveal delay={0.08 * i}>
								<div className="group overflow-hidden">
									<img
										src={w.src}
										alt={`${w.title} — interior designed by Aranya Interiors`}
										className={`${w.aspect} w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]`}
									/>
								</div>
								<Caption fig={w.fig} title={w.title} meta={w.meta} />
							</Reveal>
						</figure>
					))}
				</div>
			</div>
		</section>
	);
}

function Process() {
	return (
		<section id="process" className="relative bg-stone py-28 text-espresso md:py-40">
			<VerticalLabel className="left-6 text-espresso/40">06 — Process</VerticalLabel>
			<div className="mx-auto grid w-full max-w-[92rem] grid-cols-1 gap-16 px-6 md:px-12 lg:grid-cols-2 lg:gap-20">
				<div className="lg:sticky lg:top-32 lg:self-start">
					<Reveal>
						<SectionTag index="06" label="Process" />
					</Reveal>
					<Reveal delay={0.1}>
						<h2 className="mt-10 font-display text-4xl font-light leading-[1.05] tracking-[-0.02em] md:text-6xl">
							From first sketch
							<br />
							to final cushion.
						</h2>
					</Reveal>
					<Reveal delay={0.15}>
						<p className="mt-8 max-w-md text-sm leading-relaxed text-espresso/70">
							A fixed sequence, refined over twelve years — so you always know what happens
							next, what it costs, and when you will move in.
						</p>
						<a
							href="#contact"
							className="group mt-10 inline-flex items-center gap-3 bg-espresso px-7 py-4 text-[11px] font-medium uppercase tracking-[0.3em] text-cream transition-colors duration-300 hover:bg-brass hover:text-espresso"
						>
							Start a project
							<ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
						</a>
					</Reveal>
				</div>

				<div className="border-b border-espresso/20">
					{STEPS.map((s, i) => (
						<Reveal key={s.n} delay={i * 0.06}>
							<div className="group grid grid-cols-12 gap-4 border-t border-espresso/20 py-10 transition-colors duration-300 hover:bg-espresso/5 md:py-12">
								<span className="col-span-3 font-display text-5xl font-light text-espresso/25 transition-colors duration-300 group-hover:text-brass md:col-span-2 md:text-6xl">
									{s.n}
								</span>
								<div className="col-span-9 md:col-span-10">
									<h3 className="font-display text-2xl font-light md:text-3xl">{s.title}</h3>
									<p className="mt-3 max-w-md text-sm leading-relaxed text-espresso/70">
										{s.desc}
									</p>
								</div>
							</div>
						</Reveal>
					))}
				</div>
			</div>
		</section>
	);
}

function Stats() {
	return (
		<section className="relative bg-espresso py-20 text-cream md:py-28">
			<div className="mx-auto grid w-full max-w-[92rem] grid-cols-2 gap-y-12 px-6 md:px-12 lg:grid-cols-4">
				{STATS.map((s, i) => (
					<Reveal key={s.label} delay={i * 0.08}>
						<div className="border-l border-cream/20 pl-6 transition-colors duration-300 hover:border-brass md:pl-8">
							<div className="font-display text-5xl font-light tracking-[-0.02em] md:text-7xl">
								<CountUp value={s.value} suffix={s.suffix} />
							</div>
							<p className="mt-3 text-[10px] uppercase tracking-[0.3em] text-cream/50">
								{s.label}
							</p>
						</div>
					</Reveal>
				))}
			</div>
		</section>
	);
}

function Testimonial() {
	return (
		<section className="relative bg-cream py-28 md:py-40">
			<VerticalLabel className="left-6 text-foreground/35">08 — In their words</VerticalLabel>
			<div className="mx-auto w-full max-w-[92rem] px-6 md:px-12">
				<Reveal>
					<SectionTag index="08" label="In their words" />
				</Reveal>
				<div className="mt-12 grid grid-cols-1 gap-px border-t border-foreground/15 md:grid-cols-2">
					<Reveal delay={0.1}>
						<blockquote className="border-b border-foreground/15 py-12 md:border-b-0 md:border-r md:pr-12">
							<p className="font-display text-2xl font-light leading-[1.2] tracking-[-0.01em] md:text-4xl">
								“Aranya didn’t decorate our home — they understood it. Every room feels like it
								was always meant to be exactly this way.”
							</p>
							<footer className="mt-10 flex items-center gap-4 text-[10px] uppercase tracking-[0.3em] text-foreground/50">
								<span className="h-px w-10 bg-brass" />
								A. Kapoor — Penthouse, Mumbai
							</footer>
						</blockquote>
					</Reveal>
					<Reveal delay={0.18}>
						<blockquote className="py-12 md:pl-12">
							<p className="font-display text-2xl font-light leading-[1.2] tracking-[-0.01em] md:text-4xl">
								“They built the furniture, chose the stone, even the door handles. One team, one
								vision — and not a single thing we had to chase.”
							</p>
							<footer className="mt-10 flex items-center gap-4 text-[10px] uppercase tracking-[0.3em] text-foreground/50">
								<span className="h-px w-10 bg-brass" />
								R. &amp; M. Shah — Villa, Bengaluru
							</footer>
						</blockquote>
					</Reveal>
				</div>
			</div>
		</section>
	);
}

function Materials() {
	return (
		<section id="materials" className="relative bg-espresso py-28 text-cream md:py-40">
			<VerticalLabel className="left-6 text-cream/30">03 — Materials &amp; Decor</VerticalLabel>
			<div className="mx-auto w-full max-w-[92rem] px-6 md:px-12">
				<div className="flex flex-wrap items-end justify-between gap-6">
					<div>
						<Reveal>
							<SectionTag index="03" label="Materials & Decor" dark />
						</Reveal>
						<Reveal delay={0.1}>
							<h2 className="mt-10 max-w-3xl font-display text-4xl font-light leading-[1.05] tracking-[-0.02em] md:text-6xl">
								The decoration, sourced
								<br />
								and made <span className="font-normal italic text-brass">by hand.</span>
							</h2>
						</Reveal>
					</div>
					<Reveal delay={0.15}>
						<p className="max-w-xs text-sm leading-relaxed text-cream/60">
							Wood, stone, brass, linen and light — we supply and craft the very materials that finish your home, so nothing is left to a catalogue.
						</p>
					</Reveal>
				</div>

				<div className="mt-16 grid grid-cols-1 gap-x-8 gap-y-14 md:mt-24 sm:grid-cols-2 lg:grid-cols-3">
					{MATERIAL_LIBRARY.map((m, i) => (
						<Reveal key={m.n} delay={(i % 3) * 0.08}>
							<figure className="group">
								<div className="relative overflow-hidden">
									<img
										src={m.img}
										alt={`${m.title} — ${m.origin}, supplied by Aranya Interiors`}
										className="aspect-[4/5] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.05]"
									/>
									<div className="absolute left-4 top-4 font-display text-xs tracking-[0.3em] text-cream/70">
										{m.n}
									</div>
								</div>
								<figcaption className="mt-5 border-t border-cream/15 pt-4">
									<div className="flex items-baseline justify-between gap-4">
										<h3 className="font-display text-xl font-light tracking-[-0.01em] md:text-2xl">
											{m.title}
										</h3>
										<span className="shrink-0 text-[10px] uppercase tracking-[0.25em] text-brass">
											{m.origin}
										</span>
									</div>
									<p className="mt-3 max-w-xs text-sm leading-relaxed text-cream/60">
										{m.desc}
									</p>
								</figcaption>
							</figure>
						</Reveal>
					))}
				</div>

				<Reveal delay={0.1}>
					<div className="mt-20 flex flex-wrap items-center justify-between gap-6 border-t border-cream/15 pt-10 md:mt-28">
						<p className="max-w-md text-sm leading-relaxed text-cream/60">
							Every material is sampled in daylight and approved by you before it enters your home. Visit the studio to feel the full library.
						</p>
						<a
							href="#contact"
							className="group inline-flex items-center gap-3 border border-cream/40 px-7 py-4 text-[11px] font-medium uppercase tracking-[0.3em] text-cream transition-colors duration-300 hover:bg-brass hover:text-espresso hover:border-brass"
						>
							Visit the materials library
							<ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
						</a>
					</div>
				</Reveal>
			</div>
		</section>
	);
}

function Archive() {
	return (
		<section id="archive" className="relative bg-sand py-28 md:py-40">
			<VerticalLabel className="left-6 text-foreground/35">05 — Completed Works</VerticalLabel>
			<div className="mx-auto w-full max-w-[92rem] px-6 md:px-12">
				<div className="flex flex-wrap items-end justify-between gap-6">
					<div>
						<Reveal>
							<SectionTag index="05" label="Completed Works" />
						</Reveal>
						<Reveal delay={0.1}>
							<h2 className="mt-10 font-display text-4xl font-light leading-[1.05] tracking-[-0.02em] md:text-6xl">
								A decade of homes,
								<br />
								finished and <span className="font-normal italic text-brass">lived in.</span>
							</h2>
						</Reveal>
					</div>
					<Reveal delay={0.15}>
						<p className="max-w-xs text-sm leading-relaxed text-foreground/60">
							A small archive of delivered projects — each handed over styled, photographed, and returned to after a season.
						</p>
					</Reveal>
				</div>

				<div className="mt-16 grid grid-cols-1 gap-x-8 gap-y-16 md:mt-24 md:grid-cols-2">
					{ARCHIVE.map((a, i) => (
						<Reveal key={a.fig} delay={(i % 2) * 0.1}>
							<figure className={`group ${i % 2 === 1 ? 'md:mt-24' : ''}`}>
								<div className="overflow-hidden">
									<img
										src={a.src}
										alt={`${a.title} — ${a.type} designed by Aranya Interiors, ${a.meta}`}
										className="aspect-[3/4] w-full object-cover transition-transform duration-[1200ms] ease-out group-hover:scale-[1.05]"
									/>
								</div>
								<figcaption className="mt-5 flex items-baseline justify-between gap-4 border-t border-foreground/20 py-3 text-[10px] uppercase tracking-[0.25em] text-foreground/50">
									<span>
										{a.fig} — {a.title}
									</span>
									<span className="shrink-0 text-brass">{a.type}</span>
								</figcaption>
								<p className="text-[11px] uppercase tracking-[0.3em] text-foreground/40">{a.meta}</p>
							</figure>
						</Reveal>
					))}
				</div>
			</div>
		</section>
	);
}

function Awards() {
	return (
		<section className="relative bg-cream py-28 md:py-40">
			<VerticalLabel className="left-6 text-foreground/35">07 — Recognition</VerticalLabel>
			<div className="mx-auto w-full max-w-[92rem] px-6 md:px-12">
				<div className="grid grid-cols-1 gap-16 lg:grid-cols-12 lg:gap-20">
					<div className="lg:col-span-4 lg:sticky lg:top-32 lg:self-start">
						<Reveal>
							<SectionTag index="07" label="Recognition" />
						</Reveal>
						<Reveal delay={0.1}>
							<h2 className="mt-10 font-display text-4xl font-light leading-[1.05] tracking-[-0.02em] md:text-5xl">
								Noticed by the people who notice <span className="font-normal italic text-brass">everything.</span>
							</h2>
						</Reveal>
						<Reveal delay={0.15}>
							<p className="mt-8 max-w-sm text-sm leading-relaxed text-foreground/60">
								A quiet record of awards and editorial features — less for the trophies, more for the rooms they describe.
							</p>
						</Reveal>
					</div>

					<div className="border-b border-foreground/15 lg:col-span-8">
						{AWARDS.map((a, i) => (
							<Reveal key={a.title} delay={i * 0.06}>
								<div className="group grid grid-cols-12 items-baseline gap-4 border-t border-foreground/15 py-8 transition-colors duration-300 hover:bg-foreground/5 md:py-10">
									<span className="col-span-3 font-display text-2xl font-light text-brass md:col-span-2 md:text-3xl">
										{a.year}
									</span>
									<div className="col-span-9 md:col-span-10">
										<div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
											<h3 className="font-display text-xl font-light tracking-[-0.01em] transition-all duration-300 group-hover:translate-x-1 md:text-2xl">
												{a.title}
											</h3>
											<span className="text-[10px] uppercase tracking-[0.3em] text-foreground/45">
												{a.pub}
											</span>
										</div>
										<p className="mt-2 max-w-md text-sm leading-relaxed text-foreground/60">
											{a.note}
										</p>
									</div>
								</div>
							</Reveal>
						))}
					</div>
				</div>
			</div>
		</section>
	);
}

function Cta() {
	return (
		<section className="relative overflow-hidden">
			<img
				src={IMG.villa}
				alt="Grand double-height living space designed by Aranya Interiors at golden hour"
				className="absolute inset-0 h-full w-full object-cover"
			/>
			<div className="absolute inset-0 bg-espresso-deep/80" />
			<div className="relative mx-auto flex w-full max-w-[92rem] flex-col items-center px-6 py-32 text-center text-cream md:px-12 md:py-48">
				<Reveal>
					<SectionTag index="09" label="Begin" dark />
				</Reveal>
				<Reveal delay={0.1}>
					<h2 className="mt-10 max-w-3xl font-display text-4xl font-light leading-[1.05] tracking-[-0.02em] md:text-7xl">
						Your home is waiting
						<br />
						to be designed.
					</h2>
				</Reveal>
				<Reveal delay={0.2}>
					<a
						href="#contact"
						className="group mt-12 inline-flex items-center gap-3 bg-brass px-9 py-5 text-[11px] font-medium uppercase tracking-[0.3em] text-espresso transition-colors duration-300 hover:bg-cream"
					>
						Book a consultation
						<ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
					</a>
				</Reveal>
			</div>
		</section>
	);
}

function Footer() {
	return (
		<footer id="contact" className="relative bg-espresso-deep text-cream">
			<VerticalLabel className="right-6 text-cream/30">Mumbai — New Delhi — Bengaluru</VerticalLabel>
			<div className="mx-auto w-full max-w-[92rem] px-6 py-20 md:px-12 md:py-28">
				<div className="grid grid-cols-12 gap-12">
					<div className="col-span-12 md:col-span-5">
						<p className="font-display text-3xl font-light tracking-[0.15em]">Aranya</p>
						<p className="mt-6 max-w-sm text-sm leading-relaxed text-cream/60">
							An interior atelier for bespoke homes — architecture, furniture and decoration,
							composed under one roof since 2012.
						</p>
						<a
							href="mailto:hello@aranya.in"
							className="group mt-8 inline-flex items-center gap-3 bg-brass px-7 py-4 text-[11px] font-medium uppercase tracking-[0.3em] text-espresso transition-colors duration-300 hover:bg-cream"
						>
							Book a consultation
							<ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
						</a>
					</div>
					<div className="col-span-6 md:col-span-2">
						<p className="text-[10px] uppercase tracking-[0.3em] text-cream/40">Explore</p>
						<ul className="mt-6 space-y-3">
							{NAV.map((item) => (
								<li key={item.href}>
									<a
										href={item.href}
										className="text-sm text-cream/70 transition-colors duration-300 hover:text-brass"
									>
										{item.label}
									</a>
								</li>
							))}
						</ul>
					</div>
					<div className="col-span-6 md:col-span-2">
						<p className="text-[10px] uppercase tracking-[0.3em] text-cream/40">Studio</p>
						<p className="mt-6 text-sm leading-relaxed text-cream/70">
							14, Meadow Lane
							<br />
							Bandra West
							<br />
							Mumbai 400050
						</p>
					</div>
					<div className="col-span-12 md:col-span-3">
						<p className="text-[10px] uppercase tracking-[0.3em] text-cream/40">Contact</p>
						<p className="mt-6 text-sm leading-relaxed text-cream/70">
							<a
								href="mailto:hello@aranya.in"
								className="transition-colors duration-300 hover:text-brass"
							>
								hello@aranya.in
							</a>
							<br />
							<a
								href="tel:+919820000000"
								className="transition-colors duration-300 hover:text-brass"
							>
								+91 98200 00000
							</a>
						</p>
					</div>
				</div>
				<div className="mt-20 flex flex-wrap items-center justify-between gap-4 border-t border-cream/15 pt-8 text-[10px] uppercase tracking-[0.3em] text-cream/40">
					<span>© 2025 Aranya Interiors</span>
					<span>Sample concept website</span>
				</div>
			</div>
		</footer>
	);
}

export default function HomePage() {
	return (
		<div className="bg-cream text-foreground">
			<Helmet>
				<title>Aranya Interiors — Interior Design, Furniture &amp; Decoration</title>
				<meta
					name="description"
					content="Aranya Interiors is a premium interior atelier composing bespoke homes across India — interior architecture, bespoke furniture and decoration, from first sketch to final cushion."
				/>
			</Helmet>
			<ScrollProgress />
			<Header />
			<main>
				<Hero />
				<Marquee />
				<Philosophy />
				<Expertise />
				<Materials />
				<Works />
				<Archive />
				<Process />
				<Stats />
				<Awards />
				<Testimonial />
				<Cta />
			</main>
			<Footer />
		</div>
	);
}
